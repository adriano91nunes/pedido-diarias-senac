import { Injectable, BadRequestException } from '@nestjs/common';
import { Diaria } from './entities/diaria.entity';

@Injectable()
export class DiariasService {
  // Criamos uma lista na memória para guardar os pedidos (enquanto não ligamos o banco)
  private diarias: Diaria[] = [];

  create(dadosDoPedido: any) {
    // 1. Definição de Valores Base e Validação de Cargo
    // Criamos um mapa de cargos para facilitar a consulta e a validação
    const cargosValidos = {
      'OPERACIONAL': 200,
      'TECNICO': 350,
      'GESTAO': 600
    };

    // Trava de Segurança: Se o cargo não existir no nosso mapa, o sistema para aqui e avisa o erro
    if (!cargosValidos[dadosDoPedido.cargo]) {
      throw new BadRequestException(
        `O cargo '${dadosDoPedido.cargo}' não é válido. Escolha entre: OPERACIONAL, TECNICO ou GESTAO.`
      );
    }

    // Se passou pela trava, pegamos o valor base correspondente
    const valorBase = cargosValidos[dadosDoPedido.cargo];

    // 2. Regra do Destino: Se for Porto Alegre ou Brasília, aumenta 30%
    let valorCalculado = valorBase;
    
    // Convertemos para MAIÚSCULO para evitar erros se o usuário digitar "porto alegre" minúsculo
    const destinoInformado = dadosDoPedido.destino.toUpperCase();
    const destinosEspeciais = ['PORTO ALEGRE', 'BRASILIA'];
    
    if (destinosEspeciais.includes(destinoInformado)) {
      valorCalculado = valorCalculado * 1.30; // Aplica acréscimo de 30%
    }

    // 3. Regra da Pernoite: Se NÃO teve pernoite (bate-volta), paga só metade (50%)
    if (dadosDoPedido.temPernoite === false) {
      valorCalculado = valorCalculado * 0.5;
    }

    // 4. Criamos o objeto final com o ID e o Valor Calculado
    const novaDiaria: Diaria = {
      id: this.diarias.length + 1,
      ...dadosDoPedido,
      valorTotal: valorCalculado, // Resultado final da lógica de negócio
    };

    // Salva na nossa lista (Memória)
    this.diarias.push(novaDiaria);
    
    return novaDiaria;
  }

  // Função para listar todas as diárias cadastradas
  findAll() {
    return this.diarias;
  }
}