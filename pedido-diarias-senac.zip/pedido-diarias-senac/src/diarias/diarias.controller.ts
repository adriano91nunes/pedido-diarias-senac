import { Controller, Post, Get, Body } from '@nestjs/common';
import { DiariasService } from './diarias.service';

@Controller('diarias')
export class DiariasController {
  constructor(private readonly diariasService: DiariasService) {}

  @Post() // Rota para criar um pedido
  create(@Body() dados: any) {
    return this.diariasService.create(dados);
  }

  @Get() // Rota para ver todos os pedidos
  findAll() {
    return this.diariasService.findAll();
  }
}