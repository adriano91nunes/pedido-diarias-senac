export class CreateDiariaDto {}
