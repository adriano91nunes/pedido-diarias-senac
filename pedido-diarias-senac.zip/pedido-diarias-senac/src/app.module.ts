import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { DiariasModule } from './diarias/diarias.module';

@Module({
  imports: [DiariasModule],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
