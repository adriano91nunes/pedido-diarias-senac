# Pedido de Diárias em Órgãos Públicos - SENAC-RS

Este projeto consiste em uma API desenvolvida com **NestJS** para a gestão e cálculo automatizado de diárias para servidores públicos. O sistema foi projetado para eliminar erros manuais, aplicando regras de negócio baseadas em cargos e destinos.

## 🚀 Funcionalidades
- **Cálculo Automatizado**: Processa valores base por cargo (Operacional, Técnico e Gestão).
- **Regras de Localidade**: Aplica acréscimo de 30% para destinos especiais (Porto Alegre e Brasília).
- **Fator Pernoite**: Identifica viagens bate-volta e aplica redutor de 50%.
- **Validação de Dados**: Tratamento de exceções para cargos inexistentes.
- **Documentação Interativa**: Swagger integrado para testes rápidos.

## 🛠️ Tecnologias
- [NestJS](https://nestjs.com/) (Framework)
- [TypeScript](https://www.typescriptlang.org/) (Linguagem)
- [Swagger/OpenAPI](https://swagger.io/) (Documentação)

## 📋 Como executar
1. Instale as dependências:
   ```bash
  npm install

2. Inicie a aplicação:
   ```bash
  npm run start:dev

3. Acesse a documentação:
   ```bash
  http://localhost:3000/api